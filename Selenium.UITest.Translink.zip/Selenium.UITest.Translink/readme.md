## Description
This folder contains UI selenium tests for the Translink site.

Language and tools used:

C#, VS 2019 Community edition, Chrome 102