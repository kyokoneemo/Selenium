﻿using NUnit.Framework;
using OpenQA.Selenium;
using System;
using Shared.SharedMethods;
using Translink.UI.Tests.Pages;
using Translink.UI.Tests.Shared;


namespace Translink.UI.Tests
{
    class BusScheduleTests
    {
        public IWebDriver driver;
        public string browser;

        [SetUp]
        public void Setup()
        {
            browser = TestContext.Parameters["browser"];
            if (browser == "Firefox")
            {
                browser = "Firefox";
            }
            else // Default to Chrome
            {
                browser = "Chrome";
            }
        }

        [Test]
        public void Bus_Schedules_and_Maps_Pos()
        {
            using (var init = new TestScope(browser))
            {
                // Setup
                driver = init.Instance;

                // Arrange
                SharedMethods.GoToUrl(driver);

                // Steps
                Navigation.GotoBusSchedulePage(driver);
                var elementsList = SchedulesAndMaps.GetBusSchedulesPage(driver);

                //Assert
               Shared.Asssertions.VerifyBusSchedulePage(elementsList);
            }
        }


        [Test]
        public void Add_To_Favorites_Bus_Routes_Pos()
        {
            using (var init = new TestScope(browser))
            {
                // Setup
                driver = init.Instance;

                // Arrange
                SharedMethods.GoToUrl(driver);

                // Steps
                Navigation.GotoBusSchedulePage(driver);
                Navigation.FindBusName(driver);
                Navigation.SelectBusSchedule(driver);
                Navigation.SelectBusRoute(driver);
                Navigation.AddToFavorites(driver);

            }
        }


        private sealed class TestScope : IDisposable
        {
            public IWebDriver Instance { get; }

            //SetUp
            public TestScope(string browser)
            {
                Driver initialize = new Driver();
                Instance = initialize.StartBrowser(browser);
            }

            //TearDown
            public void Dispose()
            {
                if (Instance != null)
                {
                    Instance.Quit();
                }
            }
        }

        [TearDown]
        public void CleanUp()
        {
            if (driver != null)
            {
                driver.Quit();
            }
        }
    }
}
