﻿using NUnit.Framework;

[assembly: Parallelizable(ParallelScope.Fixtures)]
[assembly: LevelOfParallelism(2)]

namespace Translink.UI.Tests
{
    class AssemblyInfo
    {
    }
}
