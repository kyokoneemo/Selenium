﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;

namespace Translink.UI.Tests.Shared
{
    class Driver
    {
        private IWebDriver Instance { get; set; }

        //Initialize driver
        public IWebDriver StartBrowser(string browser)
        {
            //Switch to proper browser
            switch (browser)
            {
                case "Chrome":
                    ChromeOptions options = new ChromeOptions();
                    options.AddArguments("start-maximized");
                    Instance = new ChromeDriver(options);
                    Instance.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
                    break;

                case "Firefox":
                    Instance = new FirefoxDriver();
                    Instance.Manage().Window.Maximize();
                    Instance.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
                    break;
            }
            return Instance;
        }
    }
}
