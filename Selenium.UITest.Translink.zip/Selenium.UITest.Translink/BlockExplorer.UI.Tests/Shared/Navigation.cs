﻿using OpenQA.Selenium;
using Shared.SharedMethods;
using System;
using System.Threading;

namespace Translink.UI.Tests.Shared
{
    class Navigation
    {
        //Navigate to Schedules and Maps page
        internal static void GotoBusSchedulePage(IWebDriver driver)
        {
            SharedMethods.WaitUntilPreloadGone(driver);
            //Go to "Schedule and Maps > Bus"
            //SharedMethods.FindElement(driver, By.XPath("/html/body/header/div[2]/nav[2]/ul/li[4]/a"), 30).Click();
            //SharedMethods.FindElement(driver, By.LinkText("Bus Schedules | TransLink"), 30).Click();
            driver.Navigate().GoToUrl("https://www.translink.ca/schedules-and-maps/bus-schedules");
            Thread.Sleep(2000);
        }

        //Navigate to Search by transit mode, route # or name
        internal static void FindBusName(IWebDriver driver)
        {
            SharedMethods.WaitUntilPreloadGone(driver);
            //Find schedule searchbox
            SharedMethods.FindElement(driver, By.Id("find-schedule-searchbox"), 30).SendKeys("99");
            //Click Find Schedule button
            SharedMethods.FindElement(driver, By.XPath("/html/body/main/div[1]/section[3]/div/div[1]/article/section[2]/div[1]/button"), 30).Click();
            //Select #99 - UBC B-Line
            SharedMethods.FindElement(driver, By.CssSelector("#find-schedule > section.CopyMain > output.searchResultsList > article:nth-child(1) > header > a"), 30).Click();
            Thread.Sleep(2000);
        }


        //Select bus schedule
        internal static void SelectBusSchedule(IWebDriver driver)
        {
            SharedMethods.WaitUntilPreloadGone(driver);
            //Input date
            SharedMethods.FindElement(driver, By.Id("schedulestimefilter-startdate"), 30).SendKeys("08/08/2023");
            //Input Start Time
            SharedMethods.FindElement(driver, By.Id("schedulestimefilter-starttime"), 30).SendKeys("7:00 AM");
            //Select #99 - UBC B-Line
            SharedMethods.FindElement(driver, By.Id("schedulestimefilter-endtime"), 30).SendKeys("8:30 AM");
            //Click Search button
            SharedMethods.FindElement(driver, By.CssSelector("#schedules_tab > section > div > div.flexContainer.flexWrapper.verticallyCenteredContent.fullyJustifiedContent.maxWidth.useButton > button"), 30).Click();
            Thread.Sleep(2000);
        }


        //Select bus route
        internal static void SelectBusRoute(IWebDriver driver)
        {
            SharedMethods.WaitUntilPreloadGone(driver);
            //Click on the StopsPicker dropdown
            SharedMethods.FindElement(driver, By.Id("StopsPicker-listbox"), 30).Click();
            //Check stops
            SharedMethods.FindElement(driver, By.CssSelector("#StopsPicker-50913 > label > input[type=checkbox]"), 30).Click();
            SharedMethods.FindElement(driver, By.CssSelector("#StopsPicker-50916 > label > input[type=checkbox]"), 30).Click();
            SharedMethods.FindElement(driver, By.CssSelector("#StopsPicker-58613 > label > input[type=checkbox]"), 30).Click();
            //Click Selected Stops only
            SharedMethods.FindElement(driver, By.CssSelector("#content > div:nth-child(15) > section.CopyMain > div:nth-child(5) > button:nth-child(3)"), 30).Click();
            Thread.Sleep(2000);
        }

        //Add route to favourites
        internal static void AddToFavorites(IWebDriver driver)
        {
            SharedMethods.WaitUntilPreloadGone(driver);
            //Click on "Add to favourites"
            SharedMethods.FindElement(driver, By.CssSelector("#information > section.CopyMain > div > button"), 30).Click();
            //Add to favorites
            SharedMethods.FindElement(driver, By.Id("newfavourite"), 30).SendKeys("99 UBC B-Line Morning Schedule");
            SharedMethods.FindElement(driver, By.CssSelector("#add-to-favourites_dialog > form > section > div > button"), 30).Click();
            Thread.Sleep(2000);
        }
    }
}
