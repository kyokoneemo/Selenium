﻿using NUnit.Framework;
using OpenQA.Selenium;
using Shared.SharedMethods;
using System.Collections.Generic;
using System.Threading;

namespace Translink.UI.Tests.Shared
{
    class Asssertions
    { 

        /// <summary>
        /// Verify bus schedule page elements are loaded
        /// </summary>
        /// <param name="pageList"></param>
        public static void VerifyBusSchedulePage(List<string> pageList)
        {
            Assert.Multiple(() =>
            {
                Assert.AreEqual("Bus Schedule", pageList[0]);
                Assert.AreEqual("Find Schedule", pageList[1]);
                Assert.AreEqual("Try the New Trip Planner", pageList[2]);
                Assert.AreEqual("Transit System Maps", pageList[3]);
                Assert.AreEqual("Sign Up for Transit Alerts", pageList[4]);
                Assert.AreEqual("View bus schedules by region", pageList[5]);
                Assert.AreEqual("TransLink Monthly Updates", pageList[6]);
                Assert.AreEqual("Getting Around", pageList[7]);
                Assert.AreEqual("Resources", pageList[8]);
                Assert.AreEqual("Contact Us", pageList[9]);
            });
        }
    }
}
