﻿using OpenQA.Selenium;
using Shared.SharedMethods;
using System;
using System.Collections.Generic;

namespace Translink.UI.Tests.Pages
{
    class SchedulesAndMaps
    {
           internal static List<string> GetBusSchedulesPage(IWebDriver driver)
        {
            List<string> BusSchedulesPage = new List<string>();
            SharedMethods.WaitUntilPreloadGone(driver);
            string header = SharedMethods.FindElement(driver, By.XPath("/html/body/header"), 50).Text;
            string siteLogo = SharedMethods.FindElement(driver, By.XPath("/html/body/header/a"), 50).Text;
            string findSchedule = SharedMethods.FindElement(driver, By.Id("find-schedule"), 50).Text;
            string findScheduleSearchbox = SharedMethods.FindElement(driver, By.Id("find - schedule - searchbox"), 50).Text;
            string scheduleField = SharedMethods.FindElement(driver, By.Id("facet-computedtransitschedulefield"), 50).Text;
            string submitButton = SharedMethods.FindElement(driver, By.CssSelector("#find-schedule > section.CopyMain > div.contentItem.flexContainer.flexWrapper.rightJustifiedContent > button"), 50).Text;
            string tripPlanner = SharedMethods.FindElement(driver, By.Id("try-the-new-trip-planner"), 50).Text;
            string transitSystemMaps = SharedMethods.FindElement(driver, By.Id("transit-system-maps"), 50).Text;
            string footer = SharedMethods.FindElement(driver, By.CssSelector("body > div:nth-child(23) > footer > div.siteLinksFooter.maxContentWidth.fullBleed > div"), 50).Text;
            
            BusSchedulesPage.Add(header);
            BusSchedulesPage.Add(siteLogo);
            BusSchedulesPage.Add(findSchedule);
            BusSchedulesPage.Add(findScheduleSearchbox);
            BusSchedulesPage.Add(scheduleField);
            BusSchedulesPage.Add(submitButton);
            BusSchedulesPage.Add(tripPlanner);
            BusSchedulesPage.Add(transitSystemMaps);
            BusSchedulesPage.Add(footer);
            return BusSchedulesPage;
        }
    }
}
